"""Kilara Keno (working id): 40-number keno with a streak multiplier.

Every mode is one (level, picks) pair. The design and its measurements are in MATH.md.
"""

from src.config.config import Config
from src.config.distributions import Distribution
from src.config.config import BetMode


class GameConfig(Config):
    def __init__(self):
        super().__init__()
        self.game_id = "kilara_keno"
        self.provider_numer = 0
        self.working_name = "Kilara Keno"
        self.wincap = 50000
        self.win_type = "other"
        self.rtp = 0.967
        self.construct_paths()

        self.num_reels = 0
        self.num_rows = [0] * self.num_reels
        self.paytable = {}
        self.include_padding = False
        self.special_symbols = {"wild": [], "scatter": [], "multiplier": []}
        self.freespin_triggers = {self.basegame_type: {}, self.freegame_type: {}}
        self.anticipation_triggers = {self.basegame_type: 0, self.freegame_type: 0}

        # Board and draw
        self.board_numbers = 40
        self.num_draws = 10
        self.level_draws = {"low": 10, "mid": 10, "high": 10, "chain": 12}
        self.pick_sizes = [3, 5, 8, 10]

        # Highest run of consecutive hits -> multiplier on the whole win.
        self.top_streak = 7
        self.streak_multiplier = {0: 1, 1: 1, 2: 2, 3: 3, 4: 5, 5: 10, 6: 15, 7: 25}

        self.levels = ["low", "mid", "high", "chain"]
        self.chain_level = "chain"
        self.level_cost = {"low": 1.0, "mid": 1.0, "high": 1.0, "chain": 10.0}

        # pay_tables[level][picks][hits], in base bets, before the streak multiplier.
        # Found with design_tables.py.
        self.pay_tables = {
            "low": {
                3: [0, 1.2, 1.5, 9.9],
                5: [0, 0.4, 1.2, 1.5, 7.5, 50],
                8: [0, 0, 0.5, 0.8, 1.5, 5, 7.5, 15, 20],
                10: [0, 0, 0, 0.5, 1, 2, 5, 7.5, 12, 20, 20],
            },
            "mid": {
                3: [0, 0, 3, 24.4],
                5: [0, 0, 1, 2.5, 10, 100],
                8: [0, 0, 0, 0.5, 2.5, 6, 25, 100, 200],
                10: [0, 0, 0, 0, 0.6, 2, 12, 40, 100, 200, 200],
            },
            "high": {
                3: [0, 0, 1.5, 37.1],
                5: [0, 0, 0.5, 2.2, 12, 250],
                8: [0, 0, 0, 0.3, 1.5, 5, 50, 500, 2000],
                10: [0, 0, 0, 0, 0.6, 1.5, 6, 60, 600, 2000, 2000],
            },
            "chain": {
                3: [0, 11, 15, 40],
                5: [0, 4, 10, 15, 30, 80],
                8: [0, 0, 1.5, 10, 10, 15, 40, 150, 400],
                10: [0, 0, 2, 5, 5, 6, 12, 60, 300, 2000, 2000],
            },
        }

        # Every draw pattern is published this many times over, each copy with its own numbers,
        # so that a mode holds at least this many distinct rounds.
        self.min_books = 100_000

        self.bet_modes = []
        for level in self.levels:
            for picks in self.pick_sizes:
                table = self.pay_tables[level][picks]
                top = self.streak_multiplier[min(picks, self.top_streak)]
                self.bet_modes.append(
                    BetMode(
                        name=f"{level}_{picks}",
                        cost=self.level_cost[level],
                        rtp=self.rtp,
                        max_win=round(min(self.wincap, max(table) * top), 2),
                        auto_close_disabled=False,
                        is_feature=True,
                        is_buybonus=False,
                        distributions=[
                            Distribution(
                                criteria="basegame",
                                quota=1.0,
                                conditions={"reel_weights": {}, "force_wincap": False, "force_freegame": False},
                            ),
                        ],
                    )
                )

    def mode_parts(self, mode: str) -> tuple:
        """(level, picks, draws) of a mode name such as "high_8"."""
        level, picks = mode.rsplit("_", 1)
        return level, int(picks), self.level_draws[level]
