Kilara Keno (working id kilara_keno; the public name is not chosen yet)

Rules as the math implements them.

Board and draw
- The board has 40 numbers. The player picks 3, 5, 8 or 10 numbers and a level before the round.
- Low, Mid and High cost 1x the bet and draw 10 numbers, one at a time, without replacement.
- Chain costs 10x the bet and draws 12 numbers.
- A drawn number that the player picked is a hit.

Win
- Win = pay for the number of hits (table of the chosen level and pick count) x streak multiplier.
- Streak multiplier, Low / Mid / High: the longest run of hits drawn one after another.
  Run of 1: x1, 2: x2, 3: x3, 4: x5, 5: x10, 6: x15, 7 or more: x25. A miss ends the current run.
- Streak multiplier, Chain: a hit raises the level by one, a miss lowers it by one (never below
  zero). The highest level reached counts, with the same steps: level 1 x1, 2 x2, 3 x3, 4 x5,
  5 x10, 6 x15, 7 or more x25.
- The highest win of the game is 50,000x the bet (High with 8 or 10 picks, Chain with 10 picks).

Pay tables (x bet, before the multiplier; index = number of hits, from 0)
- low_3    0, 1.2, 1.5, 9.9
- low_5    0, 0.4, 1.2, 1.5, 7.5, 50
- low_8    0, 0, 0.5, 0.8, 1.5, 5, 7.5, 15, 20
- low_10   0, 0, 0, 0.5, 1, 2, 5, 7.5, 12, 20, 20
- mid_3    0, 0, 3, 24.4
- mid_5    0, 0, 1, 2.5, 10, 100
- mid_8    0, 0, 0, 0.5, 2.5, 6, 25, 100, 200
- mid_10   0, 0, 0, 0, 0.6, 2, 12, 40, 100, 200, 200
- high_3   0, 0, 1.5, 37.1
- high_5   0, 0, 0.5, 2.2, 12, 250
- high_8   0, 0, 0, 0.3, 1.5, 5, 50, 500, 2000
- high_10  0, 0, 0, 0, 0.6, 1.5, 6, 60, 600, 2000, 2000
- chain_3  0, 11, 15, 40
- chain_5  0, 4, 10, 15, 30, 80
- chain_8  0, 0, 1.5, 10, 10, 15, 40, 150, 400
- chain_10 0, 0, 2, 5, 5, 6, 12, 60, 300, 2000, 2000

Modes: <level>_<picks>, 16 in total. RTP 96.51% to 96.69% by mode (see MATH.md).

Books
- Every possible hit/miss order of a mode's draw is published the same number of times, each
  copy with its own numbers, so a mode holds a little over 100,000 different rounds. A book's
  weight is the number of real ordered draws that give its order (divided by a common factor),
  so the lookup table is the exact keno distribution. No sampling and no optimizer.
- Event "draw": level, picks, draws, selected (the book's own selected numbers, ascending),
  numbers (the numbers drawn, in order), pattern (1 = hit, 0 = miss, in draw order), hits,
  streak, multiplier, pay (hundredths of the bet).
- Live play: the player's numbers stand in for the book's. The i-th smallest number in
  "selected" is shown as the player's i-th smallest number, and the i-th smallest of the other
  numbers as the i-th smallest number the player did not choose. This is a relabelling of the
  board: hits, order and win are unchanged, and the frontend draws nothing at random.
- Replay: the RGS gives the mode and the book only, so a replay shows the book's own
  "selected" and "numbers". The draw order, hits, multiplier and win are those of the round.
- Event "finalWin": the round's win.
