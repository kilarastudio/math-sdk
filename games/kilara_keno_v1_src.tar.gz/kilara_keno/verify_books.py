"""Independent checks of the published files.

    uv run python games/kilara_keno/verify_books.py

1. Every book's payoutMultiplier equals its lookup row, ids are 0-based and in order.
2. Every book's numbers show its pattern, and its win is recomputed from that pattern with
   the rules in readme.txt.
3. A real keno draw (40 numbers, random picks, random draw order) is simulated for a few
   modes and compared with the exact RTP of the lookup table.
"""

import csv
import io
import json
import os
import random
import sys

import zstandard

sys.path.insert(0, os.path.dirname(__file__))
from game_config import GameConfig  # noqa: E402


def read_books(path):
    with open(path, "rb") as f:
        data = zstandard.ZstdDecompressor().stream_reader(f, read_across_frames=True).read()
    return [json.loads(line) for line in io.StringIO(data.decode()) if line.strip()]


def rule_win(cfg, level, picks, pattern):
    """The win of a hit/miss order, written out again from readme.txt (not imported from the game)."""
    hits = sum(pattern)
    peak = run = 0
    for hit in pattern:
        if level == "chain":
            run = run + 1 if hit else max(0, run - 1)
        else:
            run = run + 1 if hit else 0
        peak = max(peak, run)
    return round(cfg.pay_tables[level][picks][hits] * cfg.streak_multiplier[min(peak, cfg.top_streak)] * 100)


def main():
    cfg = GameConfig()
    pub = cfg.publish_path
    exact, distinct = {}, {}
    for bm in cfg.bet_modes:
        mode = bm.get_name()
        level, picks, draws = cfg.mode_parts(mode)
        books = read_books(os.path.join(pub, f"books_{mode}.jsonl.zst"))
        with open(os.path.join(pub, f"lookUpTable_{mode}_0.csv"), encoding="UTF-8") as f:
            rows = [tuple(int(x) for x in r) for r in csv.reader(f)]
        assert len(books) == len(rows), mode
        total = paid = 0
        boards = set()
        for i, (book, (sim, weight, cents)) in enumerate(zip(books, rows)):
            assert book["id"] == sim == i, (mode, i, book["id"], sim)
            assert book["payoutMultiplier"] == cents, (mode, i)
            draw = book["events"][0]
            assert draw["type"] == "draw" and len(draw["pattern"]) == draws and draw["picks"] == picks
            chosen, numbers = draw["selected"], draw["numbers"]
            assert len(set(chosen)) == picks and len(set(numbers)) == draws
            assert all(1 <= n <= cfg.board_numbers for n in chosen + numbers)
            assert [1 if n in chosen else 0 for n in numbers] == draw["pattern"], (mode, i)
            boards.add((tuple(chosen), tuple(numbers)))
            assert rule_win(cfg, level, picks, draw["pattern"]) == cents, (mode, i)
            assert cents <= cfg.wincap * 100 and weight > 0
            total += weight
            paid += weight * cents
        exact[mode] = paid / total / 100 / bm.get_cost()
        distinct[mode] = len(boards)
        assert total < 2**64
    print(f"books and lookup tables agree for {len(exact)} modes")
    print("distinct boards per mode: " + ", ".join(f"{m} {n:,}" for m, n in distinct.items()))

    random.seed(7)
    board = list(range(1, cfg.board_numbers + 1))
    for mode, rounds in (("low_8", 2_000_000), ("mid_5", 2_000_000), ("chain_5", 2_000_000), ("chain_10", 2_000_000), ("low_3", 2_000_000)):
        level, picks, draws = cfg.mode_parts(mode)
        cost = cfg.level_cost[level]
        paid = 0
        for _ in range(rounds):
            mine = set(random.sample(board, picks))
            pattern = [1 if n in mine else 0 for n in random.sample(board, draws)]
            paid += rule_win(cfg, level, picks, pattern)
        print(f"{mode}: real draws {100 * paid / rounds / 100 / cost:.3f}% over {rounds:,} rounds, lookup table {100 * exact[mode]:.3f}%")


if __name__ == "__main__":
    main()
