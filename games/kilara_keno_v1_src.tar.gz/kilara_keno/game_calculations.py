"""Exact keno arithmetic: every draw pattern of a mode, its weight and its win."""

from itertools import combinations
from math import perm

try:
    from src.executables.executables import Executables
except ImportError:  # design_tables.py runs without the SDK on the path
    Executables = object


def all_patterns(picks: int, draws: int) -> list:
    """Every ordered hit/miss pattern with at most `picks` hits, fewest hits first."""
    patterns = []
    for hits in range(min(picks, draws) + 1):
        for positions in combinations(range(draws), hits):
            hit_at = set(positions)
            patterns.append([1 if i in hit_at else 0 for i in range(draws)])
    return patterns


def pattern_weight(pattern: list, picks: int, board: int) -> int:
    """Number of ordered draws from `board` numbers that give this hit/miss pattern."""
    hits = sum(pattern)
    return perm(picks, hits) * perm(board - picks, len(pattern) - hits)


def longest_streak(pattern: list) -> int:
    best = run = 0
    for hit in pattern:
        run = run + 1 if hit else 0
        best = max(best, run)
    return best


def soft_peak(pattern: list) -> int:
    """Chain: a hit raises the level by one, a miss lowers it by one; the peak counts."""
    best = level = 0
    for hit in pattern:
        level = level + 1 if hit else max(0, level - 1)
        best = max(best, level)
    return best


def streak_of(pattern: list, level: str) -> int:
    return soft_peak(pattern) if level == "chain" else longest_streak(pattern)


class GameCalculations(Executables):
    """Win of one draw pattern."""

    def evaluate_pattern(self, pattern: list, picks: int, level: str) -> dict:
        hits = sum(pattern)
        streak = streak_of(pattern, level)
        multiplier = self.config.streak_multiplier[min(streak, self.config.top_streak)]
        pay = self.config.pay_tables[level][picks][hits]
        return {"hits": hits, "streak": streak, "multiplier": multiplier, "pay": pay, "win": round(pay * multiplier, 2)}
