"""One round: book `sim` is draw pattern `sim % patterns` of the mode, with its own numbers."""

import random

from game_override import GameStateOverride
from game_calculations import all_patterns


class GameState(GameStateOverride):
    _patterns = {}

    def patterns_for(self, picks: int, draws: int) -> list:
        if (picks, draws) not in self._patterns:
            self._patterns[(picks, draws)] = all_patterns(picks, draws)
        return self._patterns[(picks, draws)]

    def deal_numbers(self, pattern: list, picks: int) -> tuple:
        """A board that shows this pattern: the selected numbers and the numbers drawn, in order."""
        board = range(1, self.config.board_numbers + 1)
        selected = sorted(random.sample(board, picks))
        others = [n for n in board if n not in selected]
        hits = random.sample(selected, sum(pattern))
        misses = random.sample(others, len(pattern) - sum(pattern))
        numbers = [hits.pop() if hit else misses.pop() for hit in pattern]
        return selected, numbers

    def run_spin(self, sim, simulation_seed=None):
        self.reset_seed(sim)
        self.repeat = True
        while self.repeat:
            self.reset_book()
            level, picks, draws = self.config.mode_parts(self.betmode)
            patterns = self.patterns_for(picks, draws)
            pattern = patterns[sim % len(patterns)]
            selected, numbers = self.deal_numbers(pattern, picks)
            result = self.evaluate_pattern(pattern, picks, level)

            self.win_manager.update_spinwin(result["win"])
            self.win_manager.update_gametype_wins(self.gametype)
            self.book.add_event(
                {
                    "index": len(self.book.events),
                    "type": "draw",
                    "level": level,
                    "picks": picks,
                    "draws": draws,
                    "selected": selected,
                    "numbers": numbers,
                    "pattern": pattern,
                    "hits": result["hits"],
                    "streak": result["streak"],
                    "multiplier": result["multiplier"],
                    "pay": int(round(result["pay"] * 100)),
                }
            )
            self.evaluate_finalwin()
        self.imprint_wins()

    def run_freespin(self):
        pass
