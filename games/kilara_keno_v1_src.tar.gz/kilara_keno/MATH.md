# Kilara Keno (nama sementara): desain math

Status: dihitung pasti 2026-11-25 (enumerasi penuh, bukan simulasi). Belum di-commit, belum diunggah.

## Ide dalam angka

Keno papan 40 angka. Pemain memilih 3, 5, 8 atau 10 angka dan satu tingkat sebelum ronde. Angka
ditarik satu per satu; kemenangan = bayaran untuk jumlah kena × pengali rentetan. Rentetan adalah
kena berturut-turut dalam urutan tarikan, jadi urutan tarikan ikut menentukan hasil. Kemenangan
besar datang dari banyak kena yang juga beruntun (High 8 dan 10 angka, Chain 10 angka).

Pembanding live (Engine Insights dan Engine Players, 2026-11-25): Keno Xtreme (Degen Lab) RTP
96,0%, sampai 100.000×, 5 tingkat risiko dan mode 10×/100×; Dice Xtreme RTP 97,7%, 100.000×;
Darts PRO RTP 98%, 1.000×. Dua yang terakhir berada di luar pita RTP tertulis Engine, jadi tidak
ditiru.

## Aturan yang menggerakkan math

- Papan 40 angka. Low, Mid, High: harga 1×, 10 tarikan. Chain: harga 10×, 12 tarikan.
- Pengali rentetan: tingkat 1 ×1, 2 ×2, 3 ×3, 4 ×5, 5 ×10, 6 ×15, 7 atau lebih ×25.
- Low/Mid/High: tingkat = rentetan kena berturut-turut terpanjang; meleset memutus rentetan.
- Chain: kena menaikkan tingkat satu, meleset menurunkannya satu (tidak di bawah nol); tingkat
  tertinggi yang tercapai yang dipakai.
- Kemenangan tertinggi 50.000×. Tabel bayaran lengkap ada di `readme.txt` dan `game_config.py`,
  dicari dengan `design_tables.py` (angka sebulat mungkin yang RTP-nya jatuh di pita).

## Target dan hasil

Semua angka pasti (jumlah atas seluruh urutan tarikan), diukur dengan `math_audit.py` 2026-11-25.

| Mode | Harga | RTP | Std dev | Ada kemenangan | Menang ≥ harga | Max win | Peluang max win |
| --- | --- | --- | --- | --- | --- | --- | --- |
| low_3 | 1× | 96,668% | 1,92 | 58,9% | 58,9% | 30× | 1 banding 1.235 |
| low_5 | 1× | 96,517% | 3,63 | 78,3% | 36,7% | 500× | 1 banding 109.668 |
| low_8 | 1× | 96,677% | 2,56 | 65,9% | 27,7% | 500× | 1 banding 8,54 juta |
| low_10 | 1× | 96,510% | 3,05 | 48,5% | 35,1% | 500× | 1 banding 4,68 juta |
| mid_3 | 1× | 96,607% | 4,72 | 14,9% | 14,9% | 73× | 1 banding 1.235 |
| mid_5 | 1× | 96,509% | 6,79 | 36,7% | 36,7% | 1.000× | 1 banding 109.668 |
| mid_8 | 1× | 96,615% | 8,08 | 31,2% | 20,8% | 5.000× | 1 banding 8,54 juta |
| mid_10 | 1× | 96,550% | 12,16 | 19,7% | 17,2% | 5.000× | 1 banding 4,68 juta |
| high_3 | 1× | 96,692% | 6,97 | 14,9% | 14,9% | 111× | 1 banding 1.235 |
| high_5 | 1× | 96,677% | 16,09 | 36,7% | 14,5% | 2.500× | 1 banding 109.668 |
| high_8 | 1× | 96,547% | 37,80 | 31,2% | 8,9% | 50.000× | 1 banding 8,54 juta |
| high_10 | 1× | 96,655% | 49,82 | 19,7% | 17,2% | 50.000× | 1 banding 4,68 juta |
| chain_3 | 10× | 96,595% | 1,08 | 66,8% | 66,8% | 120× | 1 banding 988 |
| chain_5 | 10× | 96,608% | 1,35 | 85,1% | 47,7% | 800× | 1 banding 82.251 |
| chain_8 | 10× | 96,590% | 2,74 | 77,5% | 45,2% | 10.000× | 1 banding 1,71 juta |
| chain_10 | 10× | 96,512% | 13,01 | 88,7% | 41,5% | 50.000× | 1 banding 247.420 |

Setiap mode berisi 100.144 sampai 102.519 buku, semuanya dengan papan angka yang berbeda.

Alasan target:
- RTP 96,5-96,7%: batas atas pita Engine (96,0-96,7%), di atas Keno Xtreme (96,0%). Keputusan
  pengguna 2026-11-25.
- Setiap mode menang paling jarang 1 banding 7 (aturan Engine: tidak lebih jarang dari 1 banding 50,
  dan 90% ronde kosong bisa ditolak).
- Std dev setiap mode di bawah 60 (batas Engine); High 8 dan 10 sengaja tinggi (43-46).
- Max win tercapai lebih sering dari 1 banding 10 juta di setiap mode (pedoman Engine). Karena itu
  tangga pengali berhenti di ×25 pada tingkat 7, dan bayaran 9 dan 10 kena disamakan pada 10 angka:
  10 dari 10 hanya 1 banding 848 juta.
- Std dev tertinggi 49,8 (high_10), di bawah batas 60.

## Anggaran

RTP sebuah mode = Σ P(kena = h) × bayaran[h] × E[pengali | h] ÷ harga. P(kena) hipergeometrik
(40 angka, n pilihan, 10 atau 12 tarikan). E[pengali | h] dihitung dari semua urutan tarikan (`design_tables.py`). Tabel bayaran diatur per mode sampai jumlahnya
jatuh di 96,5-96,7%; tidak ada pembobotan ulang.

Chain berharga 10× karena nilai rata-ratanya 9,66-9,67× taruhan: tabelnya disusun agar harga bulat itu
tepat, bukan bobotnya yang digeser.

## Mode

| Tingkat | Harga | Yang berubah bagi pemain |
| --- | --- | --- |
| Low | 1× | Sering menang kecil, puncak 30-500× |
| Mid | 1× | Lebih jarang, puncak 73-5.000× |
| High | 1× | Jarang, puncak sampai 50.000× |
| Chain | 10× | 12 tarikan, dan meleset hanya menurunkan pengali satu tingkat; 42-67% ronde mengembalikan harganya |

Empat tingkat × empat ukuran pilihan = 16 mode (batas Engine 20). Nama mode `<tingkat>_<angka>`.

## Di mana varians berada

Di ekor jumlah kena dikali pengali: pada high_8, 8 kena membayar 6.000× sampai 50.000×
tergantung rentetan; pada high_10, 9 kena membayar 20.000×, 30.000× atau 50.000×. Pemain melihat pengali naik saat
kena beruntun dan jatuh saat meleset.

## Batasan Engine

- Uji kritis: semua lolos (harga termurah 1×, std ≥ 0,6, RTP dalam pita, ≤ 20 mode).
- Kelas risiko: 0 gagal. Batas taruhan dasar terbesar yang diizinkan: $1.000.
- Halaman live math-verification dibaca ulang 2026-11-25: batasnya sama dengan `math_audit.py`.

## Verifikasi

- `verify_books.py`: buku dan tabel lookup cocok di 16 mode; angka tiap buku menunjukkan polanya;
  kemenangan tiap buku dihitung ulang dari polanya dengan aturan yang ditulis ulang.
- Undian sungguhan (angka acak, urutan acak, 2 juta ronde per mode) cocok dengan tabel dalam
  1 galat baku: low_8 96,83% vs 96,68%; mid_5 96,32% vs 96,51%; chain_5 96,66% vs 96,61%;
  chain_10 97,29% vs 96,51% (galat baku 0,92); low_3 96,72% vs 96,67%.

## Keputusan dan pertanyaan terbuka

- Diputuskan pengguna 2026-11-25: Keno dengan pengali rentetan; 4 ukuran × 4 tingkat; mode
  premium Chain sekitar 10×; RTP 96,7%; max win 50.000×; dikerjakan sebelum Floppy Rabbit;
  lalu "tutup dulu risiko".
- Pilihan pembuat, belum disetujui: Chain memakai 12 tarikan dan meleset menurunkan pengali satu
  tingkat (aturan yang disetujui, "meleset tidak menurunkan pengali", membuat hasil Chain hanya
  bergantung pada jumlah kena); tangga pengali 1, 2, 3, 5, 10, 15, 25; nama mode; nama game.
- Risiko yang ditutup 2026-11-25: jumlah buku (sekarang lebih dari 100.000 per mode, tiap buku
  papan berbeda); Chain yang hanya punya 4-9 nilai kemenangan (sekarang 7-22); bayaran tidak
  bulat (tinggal 9,9; 24,4; 37,1; 2,2).
- Risiko tersisa, replay: RGS hanya memberi mode dan buku, tidak tahu angka pilihan pemain.
  Replay menampilkan papan milik buku; urutan kena, pengali dan kemenangan sama dengan ronde
  aslinya, tetapi angkanya bisa berbeda dari yang dipilih pemain. Ini tidak bisa ditutup dari
  sisi math.
- Celah pita kemenangan, ditutup 2026-11-25: tangga pengali diperpanjang (tingkat 6 ×15, 7+ ×25)
  sehingga 9 kena tidak lagi selalu membayar sama. high_10 sekarang membayar 20.000×, 30.000×
  dan 50.000×. Sisa: chain_10 kosong antara 7.500× dan 30.000×.
